from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
import descargar_video as py
import math



app = Flask(__name__);

@app.route('/')
def index():
    return render_template('index.html')

'''@app.route('/api/message',methods=['GET'])

def get_message():
    return jsonify({'message': 'Hello, World!'})
'''

@app.route('/api/data',methods=['POST'])

def receive_data():
    link = request.get_json();
    print(link,)
    link_puro = link['name'];
    print(link_puro);
    py.download_video(link_puro);
    print(link_puro);
    return jsonify({"received_data": "Video descargado"})
    

@app.route('/inicio')

def inicio():
    return render_template('index.html')


@app.route('/flora')

def flora():
    return render_template('Flora.html')

@app.route('/fauna')

def fauna():
    return render_template('fauna.html')

@app.route('/noticias')

def noticias():
    return render_template('Noticias.html')

@app.route('/BiodiversidadCundinamarca')

def cundinamarca():
    return render_template('BiodiversidadCundinamarca.html')

@app.route('/pagina_incrustada')
 
def pagina_incrustada(): 
    return render_template('mapa_cucuta.html')

@app.route('/BiodiversidadBoyaca')

def boyaca():
    return render_template('BiodiversidadBoyaca.html')

@app.route('/Prueba')

def search():
   
    df = pd.read_csv('./datos_biodiversidad_boyaca_cundinamarca.csv')
    df['Fecha_registro'] = pd.to_datetime(df['Fecha_registro'], format='%Y-%m-%d')

# Limpiar datos eliminando duplicados
    df_cleaned = df.drop_duplicates()

# Limpiar nombres de columnas
    df_cleaned.columns = df_cleaned.columns.str.strip()

    # Eliminar columnas innecesarias
    columns_to_drop = ['Latitud', 'Longitud', 'Observador', 'Comentario','Fecha_registro']
    df_cleaned = df_cleaned.drop(columns_to_drop, axis=1)

    # Contar cuántas veces se ha visto cada especie por ciudad
    especie_ciudad = df_cleaned.groupby(['Especie', 'Ciudad']).size().reset_index(name='Cantidad_veces_vista')

    # Unir el conteo de vuelta al DataFrame original
    df_cleaned = pd.merge(df_cleaned, especie_ciudad, on=['Especie', 'Ciudad'], how='left')

# Parámetros de paginación
    page = request.args.get('page', 1, type=int)
    per_page = 100
    total = len(df_cleaned)
    total_pages = math.ceil(total / per_page)

    # Calcular el índice de los datos para la página actual
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    df_cleaned = df_cleaned[start_idx:end_idx]

    # Convertir el DataFrame paginado a HTML
    html_table = df_cleaned.to_html(classes='table table-striped data-table', index=False)

    # Pasar los datos de paginación a la plantilla
    return render_template('Prueba.html', table=html_table, page=page, total_pages=total_pages)









#main
if(__name__ == '__main__'):
    app.run(debug=True);