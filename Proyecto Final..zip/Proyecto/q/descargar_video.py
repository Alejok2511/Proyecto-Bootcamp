#pip install yt-dlp
import yt_dlp

def download_video(link):
    # Create a YouTubeDL object
    ydl_opts = {
        # 'outtmpl': '%(title)s.%(ext)s',
        'format': 'audio', #MPEEG
        'merge_output_format':'mp3'
        
    }
    try: 
      with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        ydl.download([link])
        print("Descarga completa")

    except Exception as e:
     print(f"Hubo un error en la descarga: {e}");

if(__name__ == '__main__'):
   link = str(input("URL del video a descargar: ")).strip();
   download_video(link);
   

# import yt_dlp

# def list_formats(link):
#     ydl_opts = {}
#     try:
#         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#             info_dict = ydl.extract_info(link, download=False)
#             formats = info_dict.get('formats', [])
#             for format in formats:
#                 print(f"Format code: {format['format_id']} - {format['ext']} - {format['resolution']}")
#     except Exception as e:
#         print(f"Hubo un error al listar los formatos: {e}")

# def download_video(link, format_code):
#     ydl_opts = {
#         'format': format_code,
#         'merge_output_format': 'mp3'
#     }
#     try:
#         with yt_dlp.YoutubeDL(ydl_opts) as ydl:
#             ydl.download([link])
#             print("Descarga completa")
#     except Exception as e:
#         print(f"Hubo un error en la descarga: {e}")

# if __name__ == '__main__':
#     link = str(input("URL del video a descargar: ")).strip()
#     list_formats(link)
#     format_code = str(input("Ingrese el código del formato a descargar: ")).strip()
#     download_video(link, format_code)


