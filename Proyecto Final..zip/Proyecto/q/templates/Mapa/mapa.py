
import folium

ubicacion = (5.5324313, -73.3616014)

mapa = folium.Map(location= ubicacion, zoom_start=10)

folium.Marker(ubicacion, popup='Cucuta').add_to(mapa)

mapa.save('mapa_cucuta.html')

