function operacion(){

    for(var i=2; i<3;i++){
       // console.log(""+i);
      // alert(i);
    }
    //alert(i);
   // console.log("rrrrrrrrrrrrrr"+i);


   Swal.fire({
    title: 'Error!',
    text: i,
    icon: 'error',
    confirmButtonText: 'Cool'
  })


}

function example() {
  let j = 5;
  if(true) {
    let j = 10;
    console.log(j);
  }
  console.log(j);
}


